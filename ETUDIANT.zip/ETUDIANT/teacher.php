<?php
	$conn = mysqli_connect("localhost", "root", "", "dbstudent");
	
	$post_at = "";
	$post_at_to_date = "";
	
	$queryCondition = "";
	if(!empty($_POST["search"]["post_at"])) {			
		$post_at = $_POST["search"]["post_at"];
		list($fid,$fim,$fiy) = explode("-",$post_at);
		
		$post_at_todate = date('Y-m-d');
		if(!empty($_POST["search"]["post_at_to_date"])) {
			$post_at_to_date = $_POST["search"]["post_at_to_date"];
			list($tid,$tim,$tiy) = explode("-",$_POST["search"]["post_at_to_date"]);
			$post_at_todate = "$tiy-$tim-$tid";
		}
		
		$queryCondition .= "WHERE attendance_table.datesign BETWEEN '$fiy-$fim-$fid' AND '" . $post_at_todate . "'";
	}

	$sql = "SELECT attendance_table.id, student_table.name, attendance_table.datesign
			FROM attendance_table
			INNER JOIN student_table 
			ON attendance_table.iduser = student_table.id " . $queryCondition . " ORDER BY attendance_table.datesign desc";
	$result = mysqli_query($conn,$sql);
?>

<html>
	<head>
    <title>Page d'administration</title>		
		<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
		<!-- Custom fonts for this template-->
		 <!-- Custom fonts for this template-->
		 <link href="css/all.min.css" rel="stylesheet" type="text/css">
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
		<!-- Custom styles for this template-->
		<link href="css/sb-admin-2.min.css" rel="stylesheet">
		<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
		<link href="css/style3.css" rel="stylesheet">
		

		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
		<!-- Bootstrap Core CSS -->
		<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

		<!-- Custom Fonts -->
		<link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
		<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
		<link href="vendor/simple-line-icons/css/simple-line-icons.css" rel="stylesheet">

		<!-- Custom CSS -->
		<link href="css/stylish-portfolio.min.css" rel="stylesheet">

		</head>

		<body id="page-top">

		<!-- Navigation -->
		<a class="menu-toggle rounded" href="#">
		<i class="fas fa-bars"></i>
		</a>
		<nav id="sidebar-wrapper" style="background-color: green;">
		<ul class="sidebar-nav">
			<li class="sidebar-brand">
			<a class="js-scroll-trigger" href="#page-top">Menu</a>
			</li>
			<li class="sidebar-nav-item">
			<a class="js-scroll-trigger" href="index.php">Accueil</a>
			</li>
			<li class="sidebar-nav-item">
			<a class="js-scroll-trigger" href="logoutprof.php">Deconnecter</a>
			</li>
		</ul>
		</nav>

		<!-- Bootstrap core JavaScript -->
		<script src="vendor/jquery/jquery.min.js"></script>
		<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

		<!-- Plugin JavaScript -->
		<script src="vendor/jquery-easing/jquery.easing.min.js"></script>

		<!-- Custom scripts for this template -->
		<script src="js/stylish-portfolio.min.js"></script>






		<nav class="navbar navbar-expand-lg navbar-light bg-light" style="size: 20px;">
		<a class="navbar-brand" href="teacher.php">Accueil</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<a class="navbar-brand" href="logoutprof.php">Deconnecter</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		

		</nav>






    <div class="demo-content">
		<h2 class="title_with_link" style='text-align: center'>Liste des élèves signés</h2>
 <form name="frmSearch" method="post" action=""  align="center">
	  <p class="search_input">
		<input type="text" placeholder="From Date" id="post_at" name="search[post_at]"  value="<?php echo $post_at; ?>" class="input-control" />
	    <input type="text" placeholder="To Date" id="post_at_to_date" name="search[post_at_to_date]" style="margin-left:10px"  value="<?php echo $post_at_to_date; ?>" class="input-control"  />			 
		<input type="submit" name="go" value="Recherche" >
	 </p>
<form>
<?php if(!empty($result))	 { ?>
     


	<table class="customers" align="center">
		<thead>
			<tr>
			<th scope='col'>#id</th>
			<th scope='col'>Name</th>
			<th scope='col'>Date de signature</th>
			
			</tr>
			
		</thead>
					
      
    <tbody>
	<?php
		while($row = mysqli_fetch_array($result)) {
	?>
        <tr>
			<td><?php echo $row["id"]; ?></td>
			<td><?php echo $row["name"]; ?></td>
			<td><?php echo $row["datesign"]; ?></td>

		</tr>
   <?php
		}
   ?>
   <tbody>
  </table>
<?php } ?>
  </form>
  </div>
<script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
<script>
		$.datepicker.setDefaults({
		showOn: "button",
		buttonImage: "datepicker.png",
		buttonText: "Date Picker",
		buttonImageOnly: true,
		dateFormat: 'dd-mm-yy'  
		});

$(function() {
$("#post_at").datepicker();
$("#post_at_to_date").datepicker();
});
</script>
</body></html>
