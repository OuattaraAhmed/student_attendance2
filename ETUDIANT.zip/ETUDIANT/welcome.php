<?php
session_start();
include 'database/database.php'; 
?>

<!DOCTYPE html>

<html>

<head>
   
    <meta charset="utf-8" />
  
    <title>ESPACE ELEVE</title>
  
  <!-- Custom fonts for this template-->
  <link href="css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">
    
</head>

<body>
<br>
<br>

 
    <?php


$email = $_SESSION["email"];
$dup = mysqli_query($conn,"select id from student_table where email = '$email'");
$row = mysqli_fetch_assoc($dup);
$id = $row["id"];
$date = date("Y-m-d");
$time = date("H:i:s");

$verif = mysqli_query($conn,"SELECT iduser, datesign FROM attendance_table WHERE iduser='$id' AND datesign='$date' ");

if (mysqli_num_rows($verif)==0){ 

$insertion = "INSERT INTO attendance_table (iduser,datesign,time) VALUES('$id','$date','$time')";
mysqli_query($conn, $insertion);
echo "<h1 align='center'><font color='red'>Félicitation </font>, vous avez bien signé le $date à $time <h1>"; 

}
else
{ 
   echo " <h1 align='center'><font color='red'>Desolé</font>, vous avez déja signé <h1> ";

}

mysqli_close($conn);
?>

<div class="mx-auto" style="width: 200px;">
        <a href="logout.php" class="btn btn-primary"> OK </a>
    </div>

</body>

</html>