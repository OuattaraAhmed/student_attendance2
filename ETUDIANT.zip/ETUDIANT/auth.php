<?php
session_start();
include 'database/database.php'; 

// verification de numero de telephone dans la base de donnée
if (isset($_POST['telephone'])) {
	$phone = $_POST['telephone'];

	$duplicate = " SELECT telephone FROM student_table WHERE telephone='$phone' ";

	$query = mysqli_query($conn, $duplicate);
	$count = mysqli_num_rows($query);

	if ($count > 0) {
		echo "Numéro Existe Déja renseigné autre";
	} else {
		echo "juste";
	}
	exit();
}

//Verification de l'email

if (isset($_POST['email'])) {
	$emailId = $_POST['email'];

	$duplicate = " SELECT email FROM student_table WHERE email='$emailId' ";

	$query = mysqli_query($conn, $duplicate);
	$row = mysqli_num_rows($query);
	if ($row > 0) {
		echo "Email Existe Déja renseigné autre";
	} else {
		echo "Parfait";
	}
	exit();
}
//verification des deux mot de passe
if (isset($_POST['password2'])) {
	if (md5($_POST['password2']) != md5($_POST['password'])) {
		echo "les mot de passe ne correspondent pas, verifier s'il vous plait";
	} else {
		echo "Parfait";
	}
	exit();
}
?>