<!DOCTYPE html>
<html>

<head>
	<title>Connexion</title>
	<link rel="stylesheet" type="text/css" href="css/style2.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>


	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

</head>

<body>
	
<nav class="navbar navbar-expand-lg navbar-light bg-light" style="size: 20px;">
  <a class="navbar-brand" href="index.php">Accueil</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <a class="navbar-brand" href="registerprof.php">Inscription</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <a class="navbar-brand" href="signe.php">Espace eleves</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

</nav>



	
<div class="FormInscris">
        <div class="form-text" style="color: white;">Connectez vous </div>
            <div class="form-saisie" style="color:white">
						<form id="login_form" name="form1" method="post" >
							<div class="form-group">
								<label for="pwd">Email:</label>
								<input type="email" class="form-control" id="email_log" placeholder="Email" name="email">
							</div>
							<div class="form-group">
								<label for="pwd">Password:</label>
								<input type="password" class="form-control" id="password_log" placeholder="Password" name="password">
							</div>
							<input type="button" name="submit"class="btn btn-primary" value="Connexion" id="butlogin" style="background-color: #46cb49;"><br>
							Mot de passe oublié ?&nbsp;<a href="#">Cliquez ici</a><br><br>
					       Vous n'avez pas  un compte?&nbsp;<a href="registerprof.php">Cliquez ici</a>
							
						</form>
			</div>
		</div>
</div>

	<script>
		$(document).ready(function() {

			$('#butlogin').on('click', function() {
				var email = $('#email_log').val();
				var password = $('#password_log').val();
				if (email != "" && password != "") {
					$.ajax({
						url: "treatmentprof2.php",
						type: "POST",
						data: {
							type: 2,
							email: email,
							password: password
						},
						cache: false,
						success: function(dataResult) {
							var dataResult = JSON.parse(dataResult);
							if (dataResult.statusCode == 200) {
								location.href = "teacher.php";
							} else if (dataResult.statusCode == 201) {
								$("#error").show();
								$('#error').html('Invalid EmailId or Password !');
							}

						}
					});
				} else {
					alert('Please fill all the field !');
				}
			});
		});
	</script>
</body>

</html>