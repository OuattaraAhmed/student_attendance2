<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Bienvenue sur Student attendance</title>

  <!-- Bootstrap Core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom Fonts -->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
  <link href="vendor/simple-line-icons/css/simple-line-icons.css" rel="stylesheet">

  <!-- Custom CSS -->
  <link href="css/stylish-portfolio.min.css" rel="stylesheet">

</head>

<body id="page-top">

  <!-- Navigation -->
  <a class="menu-toggle rounded" href="#">
    <i class="fas fa-bars"></i>
  </a>
  <nav id="sidebar-wrapper" style="background-color: green;">
    <ul class="sidebar-nav">
      <li class="sidebar-brand">
        <a class="js-scroll-trigger" href="#page-top">Menu</a>
      </li>
      <li class="sidebar-nav-item">
        <a class="js-scroll-trigger" href="index.php">Accueil</a>
      </li>
      <li class="sidebar-nav-item">
        <a class="js-scroll-trigger" href="register.php">Inscrption élève</a>
      </li>
      <li class="sidebar-nav-item">
        <a class="js-scroll-trigger" href="signe.php">Signature élève</a>
      </li>
      <li class="sidebar-nav-item">
        <a class="js-scroll-trigger" href="prof.php">Inscrption adminitration</a>
      </li>
      <li class="sidebar-nav-item">
        <a class="js-scroll-trigger" href="registerprof.php">Connexion administration</a>
      </li>
    </ul>
  </nav>

  <!-- Header -->
  <header class="masthead d-flex">
    <div class="container text-center my-auto">
      <h1 class="mb-1"> Benvenu sur le site officiel Student attendance</h1>
      <h3 class="mb-5">
        <em>Veillez cliquez ci-dessous pour effectuer votre choix</em>
      </h3>
    <a class="btn btn-success btn-xl js-scroll-trigger" href="signe.php">Espace élève</a> <br><br><br>
    <a class="btn btn-success btn-xl js-scroll-trigger" href="prof.php">Espace adminitration</a>
    </div>
    <div class="overlay"></div>
  </header>

  

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for this template -->
  <script src="js/stylish-portfolio.min.js"></script>

</body>

</html>
