<?php 
$connect = mysqli_connect("localhost", "root", "","dbstudent");
$query = "SELECT * FROM student_table ORDER BY id desc";
$result = mysqli_query($connect, $query);
?>

<!DOCTYPE html>
<html>
    <head>
         <title>page admin</title>
         <script src="https://ajax.googleapis.com/ajax/libs/jquey/3.1.0/jquery.min.js"></script>
         <link rel="stylesheet" href="https://maxcdn.boostrapcdn.com/boostrap/3.3.6/css/boostrap.min.css" />
         <script src="https://code.jquery.com/ui/1.10.3/jquey-ui.js"></script>
         <link rel="stylesheet" href="https://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css" />

     </head>
<body>
        <br /><br />
        <div class="container" style="width: 900px;">
          <h2 align="center">rechercher</h2>
          <h3 align="center">Ordre</h3>
          <div class="col-md-3">
              <input type="text" name="from_date" id="from_date" class="form-control" placeholder="form date" />
          </div>
          <div class="col-md-3">
              <input type="text" name="to_date" id="to_date" class="form-control" placeholder="form date" />   
          </div>
          <div class="col-md-5">
              <input type="button" name="filter" id="filter" class="form-control" placeholder="recherche" /> 
          </div>

    
        </div>
</body>
</html>